package com.belle.kafka_project.rest;

import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

import com.belle.kafka_project.payload.Student;
import com.belle.kafka_project.producer.KafkaJsonProducer;
import com.belle.kafka_project.producer.KafkaProducer;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/messages")
public class MessageController {
    private final KafkaProducer kafkaProducer;
    private final KafkaJsonProducer kafkaJsonProducer;

    @PostMapping
    public ResponseEntity<String> sendMessage(
            @RequestBody String message
    ) {
        kafkaProducer.sendMessage(message);
        return ResponseEntity.ok("Message queued successfully");
    }


    @PostMapping("/json")
    public ResponseEntity<String> sendJsonMessage(
        @RequestBody Student message
    ) {
        kafkaJsonProducer.sendMessage(message);
        return ResponseEntity.ok("Message queued successfully as JSON!");
    }
}
